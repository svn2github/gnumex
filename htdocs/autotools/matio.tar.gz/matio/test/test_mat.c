/*
 * Copyright (C) 2005   Christopher C. Hulbert
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <matio.h>

static const char *helpstr[] = {
    "",
    "Usage: test_mat [OPTIONS] test [FILE] [TEST_OPTS]",
    "",
    "Runs various test on the Matlab I/O library libmatio",
    "",
    "OPTIONS",
    "-v             Sets verbose output",
    "--help         This output",
    "--help-tests   List of tests",
    "--help TEST    help information on test TEST",
    "--version      version information",
    "",
    "test        - name of the test to run",
    "FILE        - If required specifies the Matlab file to use",
    "TEST_OPTS   - If required, specify arguments to a test",
    "",
    NULL
};

static const char *helptestsstr[] = {
    "copy           - Copies one matlab file to another",
    "write          - Writes a matlab file",
    "readvar        - Reads a specific variable from a file",
    "writestruct    - Writes a structure",
    "writecell      - Writes a Cell Array",
#if 0
    "getstructfield - Uses Mat_VarGetStructField to get fields from a structure",
#endif
    "readvarinfo    - Reads a variables header information only",
    "readslab       - Tests reading a part of a dataset",
    "writeslab      - Tests writing a part of a dataset",
    "writesparse    - Tests writing a sparse matrix",
    NULL
};

static const char *helptest_copy[] = {
    "TEST: copy",
    "",
    "Usage: test_mat copy FILE",
    "",
    "  Copies FILE to test_mat_copy.mat",
    "",
    NULL
};

static const char *helptest_write[] = {
    "TEST: write",
    "",
    "Usage: test_mat write",
    "",
    "Writes various datasets to test_mat_write.mat",
    "The output file should have 6 datasets as described below",
    "",
    "Dataset Name  Data Type   Rank   Dimensions   Data",
    "---------------------------------------------------------------",
    "    d         Double      2      5x10         reshape(1:50,5,10)",
    "    f         Single      2      5x10         single(reshape(1:50,5,10))",
    "  i32         Int 32      2      5x10         int32(reshape(1:50,5,10))",
    "  i16         Int 16      2      5x10         int16(reshape(1:50,5,10))",
    "   i8         Int  8      2      5x10         int8(reshape(1:50,5,10))",
    "  str         Char        2      1x14         'This is a string'",
    "",
    NULL
};

static const char *helptest_readvar[] = {
    "TEST: readvar",
    "",
    "Usage: test_mat readvar FILE variable_name",
    "",
    "Reads variable_name from FILE and prints out it's information and data"
    "If possible",
    "",
    NULL
};

static const char *helptest_writestruct[] = {
    "TEST: writestruct",
    "",
    "Usage: test_mat writestruct",
    "",
    "Writes a structure of size 4x1 with one field (data) of various types to",
    "file test_mat_writestruct.mat",
    "",
    "Index    Data Type   Rank   Dimensions   Data",
    "---------------------------------------------------------------",
    " 1,1     Double      2      5x10         reshape(1:50,5,10)",
    " 2,1     Single      2      5x10         single(reshape(1:50,5,10))",
    " 3,1     Double      2      5x10         int32(reshape(1:50,5,10))",
    " 4,1     Struct      2      3x1          structure(1:3,1)",
    "",
    NULL
};

static const char *helptest_writecell[] = {
    "TEST: writecell",
    "",
    "Usage: test_mat writecell",
    "",
    "Writes a cell array of size 4x1 with various data types to",
    "file test_mat_writecell.mat",
    "",
    "Index    Data Type   Rank   Dimensions   Data",
    "---------------------------------------------------------------",
    " 1,1     Double      2      5x10         reshape(1:50,5,10)",
    " 2,1     Single      2      5x10         single(reshape(1:50,5,10))",
    " 3,1     Double      2      5x10         int32(reshape(1:50,5,10))",
    " 4,1     Struct      2      3x1          structure(1,1).data=cell{1},etc",
    "",
    NULL
};

static const char *helptest_getstructfield[] = {
    "TEST: copy",
    "",
    "Usage: test_mat copy FILE",
    "",
    "  Copies FILE to test_mat_copy.mat",
    "",
    NULL
};

static const char *helptest_readvarinfo[] = {
    "TEST: readvarinfo",
    "",
    "Usage: test_mat readvarinfo FILE variable_name",
    "",
    "Reads information for variable_name from FILE and prints it out",
    "",
    NULL
};

static const char *helptest_readslab[] = {
    "TEST: readslab",
    "",
    "Usage: test_mat readslab FILE variable_name",
    "",
    "Reads the corner points of the variable variable_name from file FILE and",
    "prints them out.  variable_name should be a double-precision 2-D array",
    "",
    NULL
};

static const char *helptest_writeslab[] = {
    "TEST: writeslab",
    "",
    "Usage: test_mat writeslab",
    "",
    "Writes slabs of data to test_mat_writelslab.mat  Every other element",
    "in the file is written.  Three datasets are written of types double,",
    "single, and int32",
    "",
    NULL
};

static const char *helptest_writesparse[] = {
    "TEST: writesparse",
    "",
    "Usage: test_mat writesparse",
    "",
    "Writes a sparse matrix variable with name sparse_matrix to ",
    "test_mat_writesparse.mat.  When loaded into matlab, the data should be:",
    "",
    "    (1,1)        1",
    "    (5,1)        5",
    "    (2,2)        7",
    "    (3,2)        8",
    "    (4,2)        9",
    "    (1,3)       11",
    "    (5,3)       15",
    "    (2,4)       17",
    "    (3,4)       18",
    "    (4,4)       19",
    "    (1,5)       21",
    "    (5,5)       25",
    "    (2,6)       27",
    "    (3,6)       28",
    "    (4,6)       29",
    "    (1,7)       31",
    "    (5,7)       35",
    "    (2,8)       37",
    "    (3,8)       38",
    "    (4,8)       39",
    "    (1,9)       41",
    "    (5,9)       45",
    "    (2,10)      47",
    "    (3,10)      48",
    "    (4,10)      49",
    "",
    NULL
};

static void
help_test(const char *test)
{
    if ( !strcmp(test,"copy") )
        Mat_Help(helptest_copy);
    else if ( !strcmp(test,"write") )
        Mat_Help(helptest_write);
    else if ( !strcmp(test,"readvar") )
        Mat_Help(helptest_readvar);
    else if ( !strcmp(test,"writestruct") )
        Mat_Help(helptest_writestruct);
    else if ( !strcmp(test,"writecell") )
        Mat_Help(helptest_writecell);
    else if ( !strcmp(test,"readvarinfo") )
        Mat_Help(helptest_readvarinfo);
    else if ( !strcmp(test,"readslab") )
        Mat_Help(helptest_readslab);
    else if ( !strcmp(test,"writeslab") )
        Mat_Help(helptest_writeslab);
    else if ( !strcmp(test,"writeslab") )
        Mat_Help(helptest_writeslab);
}

static int
test_write( void )
{
    int dims[2] = {5,10}, err = 0, i;
    double    d[50];
    float     f[50];
    int32_t i32[50];
    int16_t i16[50];
    int8_t   i8[50];
    char const *str = "This is a string";
    mat_t *mat;
    matvar_t *matvar;

    for ( i = 0; i < 50; i++ ) {
          d[i] = i+1;
          f[i] = i+1;
        i32[i] = i+1;
        i16[i] = i+1;
         i8[i] = i+1;
    }

    mat = Mat_Open("test_mat_write.mat",MAT_ACC_RDWR);
    if ( mat ) {
        matvar = Mat_VarCreate("d",MAT_C_DOUBLE,MAT_T_DOUBLE,2,dims,d,0);
        Mat_VarWrite( mat, matvar, 0);
        Mat_VarFree(matvar);
        matvar = Mat_VarCreate("f",MAT_C_SINGLE,MAT_T_SINGLE,2,dims,f,0);
        Mat_VarWrite( mat, matvar, 0);
        Mat_VarFree(matvar);
        matvar = Mat_VarCreate("i32",MAT_C_INT32,MAT_T_INT32,2,dims,i32,0);
        Mat_VarWrite( mat, matvar, 0);
        Mat_VarFree(matvar);
        matvar = Mat_VarCreate("i16",MAT_C_INT16,MAT_T_INT16,2,dims,i16,0);
        Mat_VarWrite( mat, matvar, 0);
        Mat_VarFree(matvar);
        matvar = Mat_VarCreate("i8",MAT_C_INT8,MAT_T_INT8,2,dims,i8,0);
        Mat_VarWrite( mat, matvar, 0);
        Mat_VarFree(matvar);
        dims[0] = 1;
        dims[1] = strlen(str);
        matvar = Mat_VarCreate("str",MAT_C_CHAR,MAT_T_INT8,2,dims,str,0);
        Mat_VarWrite( mat, matvar, 0);
        Mat_VarFree(matvar);
        Mat_Close(mat);
    } else {
        err = 1;
    }

    return err;
}

static int
test_readvar(const char *inputfile, const char *var)
{
    int err = 0;
    mat_t *mat;
    matvar_t *matvar;

    mat = Mat_Open(inputfile,MAT_ACC_RDONLY);
    if ( mat ) {
        matvar = Mat_VarRead(mat,var);
        if ( matvar == NULL ) {
            err = 1;
        } else {
            Mat_VarPrint( matvar, 1);
            Mat_VarFree(matvar);
        }
        Mat_Close(mat);
    } else {
        err = 1;
    }
    return err;
}

static int
test_write_struct()
{
    int   dims[2] = {5,10},start[2]={0,0},stride[2]={1,1},edge[2]={5,10};
    double  data[50]={0.0,};
    float  fdata[50]={0.0,};
    int    idata[50]={0.0,};
    int    err = 0, i;
    mat_t     *mat;
    matvar_t **matvar, *struct_matvar, *substruct_matvar;
    
    for ( i = 0; i < 50; i++ ) {
         data[i] = i+1;
        fdata[i] = i+1;
        idata[i] = i+1;
    }

    mat = Mat_Create("test_mat_writestruct.mat",NULL);
    if ( mat ) {
        matvar = malloc(5*sizeof(matvar_t *));
        matvar[0] = Mat_VarCreate("data",MAT_C_DOUBLE,MAT_T_DOUBLE,2,
                       dims,data,MEM_CONSERVE);
        matvar[1] = Mat_VarCreate("data",MAT_C_SINGLE,MAT_T_SINGLE,2,
                       dims,fdata,MEM_CONSERVE);
        matvar[2] = Mat_VarCreate("data",MAT_C_INT32,MAT_T_INT32,2,
                       dims,idata,MEM_CONSERVE);
        matvar[3] = NULL;
        dims[0] = 3;
        dims[1] = 1;
        substruct_matvar = Mat_VarCreate("data",MAT_C_STRUCT,MAT_T_STRUCT,
                            2,dims,matvar,0);
        matvar[3] = substruct_matvar;
        dims[0] = 4;
        dims[1] = 1;
        struct_matvar = Mat_VarCreate("structure",MAT_C_STRUCT,MAT_T_STRUCT,2,
                            dims,matvar,0);
        Mat_VarWrite(mat,struct_matvar,0);
        free(matvar[0]);
        free(matvar[1]);
        free(matvar[2]);
        free(matvar);
        free(struct_matvar);
        free(substruct_matvar);
        Mat_Close(mat);
    }
    return err;
}

static int
test_write_cell()
{
    int   dims[2] = {5,10},start[2]={0,0},stride[2]={1,1},edge[2]={5,10};
    double  data[50]={0.0,};
    float  fdata[50]={0.0,};
    int    idata[50]={0.0,};
    int    err = 0, i;
    mat_t     *mat;
    matvar_t **matvar, *struct_matvar, *substruct_matvar;
    
    for ( i = 0; i < 50; i++ ) {
         data[i] = i+1;
        fdata[i] = i+1;
        idata[i] = i+1;
    }

    mat = Mat_Create("test_mat_writecell.mat",NULL);
    if ( mat ) {
        matvar = malloc(5*sizeof(matvar_t *));
        matvar[0] = Mat_VarCreate("data",MAT_C_DOUBLE,MAT_T_DOUBLE,2,
                       dims,data,MEM_CONSERVE);
        matvar[1] = Mat_VarCreate("data",MAT_C_SINGLE,MAT_T_SINGLE,2,
                       dims,fdata,MEM_CONSERVE);
        matvar[2] = Mat_VarCreate("data",MAT_C_INT32,MAT_T_INT32,2,
                       dims,idata,MEM_CONSERVE);
        matvar[3] = NULL;
        dims[0] = 3;
        dims[1] = 1;
        substruct_matvar = Mat_VarCreate("structure",MAT_C_STRUCT,MAT_T_STRUCT,
                            2,dims,matvar,0);
        matvar[3] = substruct_matvar;
        dims[0] = 4;
        dims[1] = 1;
        struct_matvar = Mat_VarCreate("cell",MAT_C_CELL,MAT_T_CELL,2,
                            dims,matvar,0);
        Mat_VarWrite(mat,struct_matvar,0);
        free(matvar[0]);
        free(matvar[1]);
        free(matvar[2]);
        free(matvar);
        free(struct_matvar);
        free(substruct_matvar);
        Mat_Close(mat);
    }
    return err;
}

static int
test_get_struct_field( const char *file )
{
    mat_t *mat;
    matvar_t *matvar, *field;
    int index = 1;

    mat = Mat_Open(file,MAT_ACC_RDONLY);
    if ( mat ) {
        matvar = Mat_VarRead(mat,"structure");
        if ( matvar ) {
            field = Mat_VarGetStructField(matvar,"name",BY_NAME,1,1);
            Mat_VarPrint( field, 0);
            index = 2;
            field = Mat_VarGetStructField(matvar,&index,BY_INDEX,1,1);
            Mat_VarPrint( field, 0);

            field = Mat_VarGetStructField(matvar,"name",BY_NAME,2,2);
            Mat_VarPrint( field, 0);
            index = 2;
            field = Mat_VarGetStructField(matvar,&index,BY_INDEX,2,2);
            Mat_VarPrint( field, 0);

            field = Mat_VarGetStructField(matvar,"name",BY_NAME,2,3);
            Mat_VarPrint( field, 0);
            index = 2;
            field = Mat_VarGetStructField(matvar,&index,BY_INDEX,2,3);
            Mat_VarPrint( field, 0);

            Mat_VarFree(matvar);
        }
        Mat_Close(mat);
    }
}

static int
test_readslab(const char *file, const char *var)
{
    int   start[2]={0,0},stride[2]={1,1},edge[2]={2,2}, err = 0;
    double ptr[4];
    mat_t  *mat;
   matvar_t *matvar;

    mat = Mat_Open(file,MAT_ACC_RDONLY);
    if ( mat ) {
        matvar = Mat_VarReadInfo(mat,var);
        if ( matvar != NULL ) {
            stride[0] = matvar->dims[0]-1;
            stride[1] = matvar->dims[1]-1;
            Mat_VarReadData(mat,matvar,ptr,start,stride,edge);
            printf("%f    %f\n%f    %f",ptr[0],ptr[1],ptr[2],ptr[3]);
            Mat_VarFree(matvar);
        } else {
            err = 1;
        }
        Mat_Close(mat);
    } else {
        err = 1;
    }
    return err;
}

static int
test_writesparse( void )
{
    int dims[2] = {5,10}, err = 0, i;
    double    d[50] = {1,5,7,8,9,11,15,17,18,19,21,25,27,28,29,31,35,37,38,39,
                       41,45,47,48,49};
    int32_t  ir[25] = {0,4,1,2,3,0,4,1,2,3,0,4,1,2,3,0,4,1,2,3,0,4,1,2,3};
    int32_t  jc[11] = {0,2,5,7,10,12,15,17,20,22,25};
    mat_t *mat;
    matvar_t *matvar;
    sparse_t  sparse = {0,};

    sparse.nzmax = 25;
    sparse.nir   = 25;
    sparse.ir    = ir;
    sparse.njc   = 11;
    sparse.jc    = jc;
    sparse.ndata = 25;
    sparse.data  = d;
    mat = Mat_Open("test_mat_writesparse.mat",MAT_ACC_RDWR);
    if ( mat ) {
        matvar = Mat_VarCreate("sparse_matrix",MAT_C_SPARSE,
                       MAT_T_DOUBLE,2,dims,&sparse,MEM_CONSERVE);
        if ( matvar != NULL ) {
            Mat_VarWrite( mat, matvar, 0);
            Mat_VarFree(matvar);
        } else {
            Mat_Critical("test_writesparse: Couldn't create matlab variable");
            err = 1;
        }
        Mat_Close(mat);
    } else {
        err = 1;
    }

    return err;
}

int main (int argc, char *argv[])
{
    char *prog_name = "test_mat";
    int   i, k, err = 0;
    mat_t *mat, *mat2;
    matvar_t *matvar, *matvar2, *matvar3;

    Mat_LogInit(prog_name);

    if ( argc < 2 ) {
        Mat_Error("Must specify a test, or --help");
    } else if  ( (argc == 2) && !strcmp(argv[1],"--help") ) {
        Mat_Help(helpstr);
    } else if  ( (argc == 2) && !strcmp(argv[1],"--help-tests") ) {
        Mat_Help(helptestsstr);
    } else if  ( (argc == 3) && !strcmp(argv[1],"--help") ) {
        help_test(argv[2]);
    }

    for ( k = 1; k < argc; ) {
        if ( !strcasecmp(argv[k],"copy") ) {
            k++;
            mat = Mat_Create("test_mat_copy.mat",NULL);
            mat2 = Mat_Open(argv[k++],MAT_ACC_RDONLY);
            if ( mat && mat2 ) {
                while ( NULL != (matvar = Mat_VarReadNext(mat2)) )
                    Mat_VarWrite( mat, matvar, 0);
                Mat_Close(mat);
                Mat_Close(mat2);
            }
        } else if ( !strcasecmp(argv[k],"write") ) {
            k++;
            err += test_write();
        } else if ( !strcasecmp(argv[k],"readvar") ) {
            k++;
            if ( argc < 4 ) {
                Mat_Critical("Must specify the input file and variable respectively");
                err++;
            } else {
                err += test_readvar(argv[k],argv[k+1]);
                k+=2;
            }
        } else if ( !strcasecmp(argv[k],"writestruct") ) {
            k++;
            err += test_write_struct();
        } else if ( !strcasecmp(argv[k],"writecell") ) {
            k++;
            err += test_write_cell();
        } else if ( !strcasecmp(argv[k],"getstructfield") ) {
            k++;
            err += test_get_struct_field(argv[k++]);
        } else if ( !strcasecmp(argv[k],"readvarinfo") ) {
            k++;
            mat = Mat_Open(argv[k++],MAT_ACC_RDONLY);
            if ( mat ) {
                matvar = Mat_VarReadInfo(mat,argv[k++]);
                if ( matvar ) {
                    Mat_VarPrint( matvar, 0);
                    Mat_VarFree(matvar);
                }
                Mat_Close(mat);
            } else {
                k++;
                err ++;
            }
        } else if ( !strcasecmp(argv[k],"writeslab") ) {
            int   dims[2] = {6,10},start[2]={0,0},stride[2]={2,2},edge[2]={3,5};
            double  data[60]={0.0,};
            float  fdata[60]={0.0,};
            int    idata[60]={0.0,};
            void *ptr;
    
            k++;
            for ( i = 0; i < 60; i++ ) {
                 data[i] = i+1;
                fdata[i] = i+1;
                idata[i] = i+1;
            }
    
            mat = Mat_Create("test_mat_writeslab.mat",NULL);
            if ( mat ) {
                matvar = Mat_VarCreate("d",MAT_C_DOUBLE,MAT_T_DOUBLE,2,
                               dims,NULL,0);
                matvar2 = Mat_VarCreate("f",MAT_C_SINGLE,MAT_T_SINGLE,2,
                               dims,NULL,0);
                matvar3 = Mat_VarCreate("i",MAT_C_INT32,MAT_T_INT32,2,
                               dims,NULL,0);
                Mat_VarWriteInfo(mat,matvar);
                Mat_VarWriteInfo(mat,matvar2);
                Mat_VarWriteInfo(mat,matvar3);
                Mat_VarWriteData(mat,matvar3,idata,start,stride,edge);
                Mat_VarWriteData(mat,matvar,data,start,stride,edge);
                Mat_VarWriteData(mat,matvar2,fdata,start,stride,edge);
                Mat_VarFree(matvar);
                Mat_VarFree(matvar2);
                Mat_VarFree(matvar3);
                Mat_Close(mat);
            }
    #if 0
        } else if ( !strcasecmp(argv[1],"cellslab") ) {
            matvar_t *cellmatvar, **cellfields;
                cellfields = malloc(6*sizeof(matvar_t *));
                cellfields[0] = matvar;
                cellfields[1] = matvar2;
                cellfields[2] = matvar3;
                cellfields[3] = matvar;
                cellfields[4] = matvar2;
                cellfields[5] = matvar3;
                dims[0] = 3;
                dims[1] = 2;
                cellmatvar = Mat_VarCreate("c",MAT_C_CELL,MAT_T_CELL,2,
                               dims,cellfields,0);
                Mat_VarWriteInfo(mat,cellmatvar);
                Mat_VarPrint(Mat_VarGetCell(cellmatvar,1,1),0);
                cellmatvar->data = NULL;
                Mat_VarFree(cellmatvar);
    #endif
        } else if ( !strcasecmp(argv[k],"readslab") ) {
            k++;
            test_readslab(argv[k],argv[k+1]);
            k+=2;
        } else if ( !strcasecmp(argv[k],"slab3") ) {
            int   start[3]={1,1,1},stride[3]={1,1,1},edge[3]={1,1,1};
            int j, k;
            double ptr[150] = {0,};
    
            k++;
            mat = Mat_Open("test_slab_d3.mat",MAT_ACC_RDONLY);
            if ( mat ) {
                matvar = Mat_VarReadInfo(mat,"d3");
                Mat_VarReadData(mat,matvar,ptr,start,stride,edge);
                for ( i = 0; i < 3; i++ ) {
                   for ( j = 0; j < 5; j++ ) {
                      for ( k = 0; k < 10; k++ )
                          printf("%f ",*(ptr+50*i+5*k+j));
                      printf("\n");
                    }
                    printf("\n\n");
                }
                Mat_VarFree(matvar);
                Mat_Close(mat);
            }
        } else if ( !strcasecmp(argv[k],"writesparse") ) {
            k++;
            test_writesparse();
        } else {
            Mat_Warning("Unrecognized test %s", argv[k]);
            k++;
        }
    }
    
    return 0;
}
