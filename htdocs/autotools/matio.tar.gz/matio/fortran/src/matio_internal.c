#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <matio.h>

#define fmat_loginit_c \
            FC_FUNC(fmat_loginit_c,FMAT_LOGINIT_C)
#define fmat_open_c \
            FC_FUNC(fmat_open_c,FMAT_OPEN_C)
#define fmat_close_c \
            FC_FUNC(fmat_close_c,FMAT_CLOSE_C)
#define fmat_varcreate_c \
            FC_FUNC(fmat_varcreate_c,FMAT_VARCREATE_C)
#define fmat_varfree_c \
            FC_FUNC(fmat_varfree_c,FMAT_VARFREE_C)
#define fmat_varprint_c \
            FC_FUNC(fmat_varprint_c,FMAT_VARPRINT_C)
#define fmat_varread_c \
            FC_FUNC(fmat_varread_c,FMAT_VARREAD_C)
#define fmat_varreaddata_c \
            FC_FUNC(fmat_varreaddata_c,FMAT_VARREADDATA_C)
#define fmat_varreadinfo_c \
            FC_FUNC(fmat_varreadinfo_c,FMAT_VARREADINFO_C)
#define fmat_varwriteinfo_c \
            FC_FUNC(fmat_varwriteinfo_c,FMAT_VARWRITEINFO_C)
#define fmat_varwritedata_c \
            FC_FUNC(fmat_varwritedata_c,FMAT_VARWRITEDATA_C)
#define fmat_getinfo \
            FC_FUNC(fmat_getinfo,FMAT_GETINFO)

extern void
fmat_loginit_c(char *prog_name, int len)
{
    char *name;

    name = malloc(len+1);
    strncpy(name,prog_name,len);
    name[len] = '\0';
    Mat_LogInit(name);
    free(name);
    return;
}

extern int
fmat_open_c(char *filename, int *mode, mat_t *mat, int len)
{
    char *fname;
    int err = 0;
    mat_t *mat2;

    fname = malloc(len+1);
    strncpy(fname,filename,len);
    fname[len] = '\0';

    if ( NULL == (mat2 = Mat_Open(fname,*mode)) ) {
        Mat_Critical("Error opening file %s", fname);
        err = 1;
    } else {
        memcpy(mat,mat2,sizeof(mat_t));
    }
    free(fname);

    return err;
}

extern int
fmat_close_c(mat_t *mat)
{
    mat_t *mat2;

    mat2 = malloc(sizeof(mat_t));
    memcpy(mat2,mat,sizeof(mat_t));
    mat->fp = NULL;
    mat->header = NULL;
    mat->subsys_offset = NULL;
    if ( mat2 != NULL )
        Mat_Close(mat2);
    else
        return 1;
    return 0;
}

extern void
fmat_varprint_c(matvar_t *matvar)
{
    Mat_VarPrint(matvar,1);
    return;
}

extern int
fmat_varreadinfo_c(mat_t *mat,char *name,matvar_t *matvar,int len)
{
    char *varname;
    int   err = 0;
    matvar_t *matvar_c = NULL;

    varname = malloc(len+1);
    if ( varname != NULL ) {
        strncpy(varname,name,len);
        varname[len] = '\0';

        matvar_c = Mat_VarReadInfo(mat,varname);
        if ( matvar_c != NULL ) {
            memcpy(matvar,matvar_c,sizeof(matvar_t));
            matvar->dims = matvar_c->dims;
            free(matvar_c);
        } else {
            err = 1;
        }
    } else {
        err = 1;
    }

    return err;
}

extern int
fmat_varread_c(mat_t *mat,char *name,matvar_t *matvar,int len)
{
    char *varname;
    int   err;
    matvar_t *matvar_c = NULL;

    varname = malloc(len+1);
    if ( varname != NULL ) {
        strncpy(varname,name,len);
        varname[len] = '\0';

        matvar_c = Mat_VarRead(mat,varname);
        if ( matvar_c != NULL )
            memcpy(matvar,matvar_c,sizeof(matvar_t));
    } else {
        err = 1;
    }

    return err;
}

extern int
fmat_varreaddata_c(mat_t *mat,matvar_t *matvar,char *data,int *start,int *stride,int *edge)
{
    int *start_c, *stride_c, *edge_c, err, i;

    if ( (start == NULL) || (stride == NULL) || (edge == NULL) ) {
        start_c  = malloc(matvar->rank*sizeof(int));
        stride_c = malloc(matvar->rank*sizeof(int));
        edge_c   = malloc(matvar->rank*sizeof(int));
        if ( (start_c == NULL) || (stride_c == NULL) || (edge_c == NULL) ) {
            err = 1;
        } else {
            for ( i = 0; i < matvar->rank; i++ ) {
                start_c[i]  = 0;
                stride_c[i] = 1;
                edge_c[i]   = matvar->dims[i];
            }
            err = Mat_VarReadData(mat,matvar,(data),start_c,stride_c,edge_c);
            free(start);
            free(stride);
            free(edge);
        }
    } else {
        err = Mat_VarReadData(mat,matvar,(data),start,stride,edge);
    }

    return err;
}

extern int
fmat_varwriteinfo_c(mat_t *mat,matvar_t *matvar)
{
    int err = 0;
    if ( (mat == NULL) || (matvar == NULL) )
        err =  1;
    else if ( (matvar->name == NULL) || (matvar->dims == NULL) )
        err = 2;
    else {
        err = Mat_VarWriteInfo(mat,matvar);
    }

    return 0;
}

extern int
fmat_varwritedata_c(mat_t *mat,matvar_t *matvar,void *data,int *start,
    int *stride,int *edge)
{
    int *start_c, *stride_c, *edge_c, err, i;

    if ( (start == NULL) || (stride == NULL) || (edge == NULL) ) {
        start_c  = malloc(matvar->rank*sizeof(int));
        stride_c = malloc(matvar->rank*sizeof(int));
        edge_c   = malloc(matvar->rank*sizeof(int));
        if ( (start_c == NULL) || (stride_c == NULL) || (edge_c == NULL) ) {
            err = 1;
        } else {
            for ( i = 0; i < matvar->rank; i++ ) {
                start_c[i]  = 0;
                stride_c[i] = 1;
                edge_c[i]   = matvar->dims[i];
            }
            err = Mat_VarWriteData(mat,matvar,data,start_c,stride_c,edge_c);
            free(start_c);
            free(stride_c);
            free(edge_c);
        }
    } else {
        err = Mat_VarWriteData(mat,matvar,data,start,stride,edge);
    }

    return err;
}

extern int
fmat_varcreate_c(int *rank,int *dims,char *name,int *class_type,
    int *data_type, matvar_t *matvar,int len)
{
    char *varname;
    int err = 0;
    matvar_t *matvar_c;

    varname = malloc(len+1);
    if ( varname != NULL ) {
        strncpy(varname,name,len);
        varname[len] = '\0';
        matvar_c = Mat_VarCreate(varname,*class_type,*data_type,*rank,dims,NULL,0);
        if ( matvar_c == NULL ) {
            Mat_Critical("Mat_VarCreate returned NULL");
            err = 1;
        } else {
            memcpy(matvar,matvar_c,sizeof(matvar_t));
            free(matvar_c);
        }
    }
    Mat_Message("err = %d",err);
    return err;
}

extern int
fmat_varfree_c(matvar_t * matvar)
{
    matvar_t *matvar2;

    matvar2 = malloc(sizeof(matvar_t));
    memcpy(matvar2,matvar,sizeof(matvar_t));
    Mat_VarFree(matvar2);
    matvar->data = NULL;
    matvar->dims = NULL;
    matvar->name = NULL;
    matvar->z    = NULL;

    return 0;
}

extern void fmat_getinfo(matvar_t *matvar, int *rank, int *dims)
{
    *rank = matvar->rank;
    memcpy(dims,matvar->dims,matvar->rank*sizeof(int));
}
