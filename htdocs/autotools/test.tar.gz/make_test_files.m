% Make easy numeric/character matrices
d=reshape(1:50,5,10);
s=single(d);
i32=int32(d);
i16=int16(d);
i8=int8(d);
c=['char array1';'char array2'];

% Make sparse variables
sp_diag=sparse(diag(1:10));
sp=sparse([1 0 11 0 21 0 31 0 41 0;
           2 0 12 0 22 0 32 0 42 0;
           3 0 13 0 23 0 33 0 43 0;
           4 0 14 0 24 0 34 0 44 0;
           5 0 15 0 25 0 35 0 45 0]);

% Make variables whose data will be stored in the tag
d_in_tag   = 1:4;
s_in_tag   = single(d);
i32_in_tag = int32(d);
i16_in_tag = int16(d);
i8_in_tag  = int8(d);
c_in_tag   = '1234';


%Make some structures
easy.d   = d;
easy.s   = s;
easy.i32 = i32;
easy.i16 = i16;
easy.i8  = i8;
easy.c   = c;

easy_with_sparse_and_tag.d   = d;
easy_with_sparse_and_tag.s   = s;
easy_with_sparse_and_tag.i32 = i32;
easy_with_sparse_and_tag.i16 = i16;
easy_with_sparse_and_tag.i8  = i8;
easy_with_sparse_and_tag.c   = c;
easy_with_sparse_and_tag.d_in_tag   = d_in_tag;
easy_with_sparse_and_tag.s_in_tag   = s_in_tag;
easy_with_sparse_and_tag.i32_in_tag = i32_in_tag;
easy_with_sparse_and_tag.i16_in_tag = i16_in_tag;
easy_with_sparse_and_tag.i8_in_tag  = i8_in_tag;
easy_with_sparse_and_tag.c_in_tag   = c_in_tag;
easy_with_sparse_and_tag.sp         = sp;
easy_with_sparse_and_tag.sp_diag    = sp_diag;


struct_nested.easy = easy;
struct_nested.easy_with_sparse_and_tag = easy_with_sparse_and_tag;


% Make some cell arrays
cells{1,1} = d;
cells{2,1} = s;
cells{3,1} = i32;
cells{1,2} = i16;
cells{2,2} = i8;
cells{3,2} = c;

cells_with_structs{1} = easy;
cells_with_structs{2} = easy_with_sparse_and_tag;

save -v6 test_be_v6.mat
save     test_be.mat
