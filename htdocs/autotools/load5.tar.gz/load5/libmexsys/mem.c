/*
 * $Revision: 1.1.2.1 $ $State: Exp $
 * $Date: 2005/08/05 16:24:32 $
 */
#include <mex.h>

static int ncalloc = 0;
static int nmalloc = 0;
static int nfree = 0;

void *
__wrap_malloc(size_t size)
{
    void *ptr = NULL;
    nmalloc++;
    ptr = mxMalloc(size);
    if ( ptr != NULL )
        mexMakeMemoryPersistent(ptr);
    return ptr;
}

void *
__wrap_calloc(size_t nmemb, size_t size)
{
    void *ptr = NULL;
    ncalloc++;
    ptr = mxCalloc(nmemb,size);
    if ( ptr != NULL )
        mexMakeMemoryPersistent(ptr);
    return ptr;
}

void *
__wrap_realloc(void *ptr, size_t size)
{
    void *ptr2 = NULL;
    nmalloc++;
    ptr2 = mxRealloc(ptr,size);
    if ( ptr2 != NULL )
        mexMakeMemoryPersistent(ptr2);
    return ptr;
}

void
__wrap_free(void *ptr)
{
    nfree++;
    return mxFree(ptr);
}

void __wrap_assert(int expression)
{
    return mxAssert(expression,NULL);
}

void *
__wrap_zcalloc(void *opaque, unsigned nmemb, unsigned size)
{
    ncalloc++;
    return mxCalloc(nmemb,size);
}

void
__wrap_zcfree(void *opaque, void *ptr)
{
    nfree++;
    return mxFree(ptr);
}

void
MexMemProfile( int *m, int *c, int *f )
{
    *m = nmalloc;
    *c = ncalloc;
    *f = nfree;
    return;
}

void
MexMemReset( )
{
    nmalloc = 0;
    ncalloc = 0;
    nfree = 0;
    return;
}
