/** @file load5.c
 * @brief Loads a Matlab MAT level 5 file
 *
 * Loads in a Matlab MAT level 5 file
 * @synopsis
 *    load5 [OPTIONS] MAT_FILE [VAR1 VAR2 ...]
 * @options
 * @opt --prefix    prepends PREFIX to variables loaded from MAT file",
 *                  except variable names explicitly set using '=' @endopt
 * @opt --suffix    appends SUFFIX to variables loaded from MAT file",
 *                  except variable names explicitly set using '=' @endopt
 * @opt --help      Print help string and exit @endopt
 * @opt --version   Print version number and exit @endopt
 *
 * @examples
 * @code
 *    >> load5 --prefix pre_ --suffix _suf dem dLat dLon TerrainHeight=th
 *    >> whos
 *      Name               Size                   Bytes  Class
 * 
 *      pre_dLat_suf       1x1                        8  double array
 *      pre_dLon_suf       1x1                        8  double array
 *      th              1440x1441               2075040  uint8 array
 *
 *    Grand total is 2075042 elements using 2075056 bytes
 *
 *    >>"
 * @endcode
 *
 * @code
 *    >> load5('--prefix','pre_','--suffix','_suf','dem.mat');
 *    >> whos
 *      Name                            Size                   Bytes  Class
 *
 *      pre_SouthmostLatitude_suf       1x1                        8  double array
 *      pre_TerrainHeight_suf        1440x1441               2075040  uint8 array
 *      pre_WestmostLongitude_suf       1x1                        8  double array
 *      pre_dLat_suf                    1x1                        8  double array
 *      pre_dLon_suf                    1x1                        8  double array
 *
 *    Grand total is 2075044 elements using 2075072 bytes",
 *
 *    >>
 * @endcode
 *
 * @code
 *    >> load5 test.mat
 *    >>
 * @endcode
 */
/*
 * $Revision: 1.1.2.2 $ $State: Exp $
 * $Date: 2005/08/05 16:38:31 $
 */
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <mexstd.h>
#include <mexio.h>
#include <matio.h>

#ifdef WINNT
#define PATHSEP '\\'
#else
#define PATHSEP '/'
#endif

static char *prefix = NULL;
static char *suffix = NULL;

extern int      mexoptind;
extern char    *mexoptarg;
extern mxArray *mxArrayoptarg;

static char *helpstr[] = {
    "",
    "Usage: load5([OPTIONS],filename,var1,var2,...)",
    "       load5 [OPTIONS] filename var1 var2 ...",
    "       load5 [OPTIONS] filename var1as=var1 var2as=var2",
    "",
    "  Loads a Matlab MAT version 5 compatible file",
    "",
    "  OPTIONS",
    "    --help          - This output",
    "    --version       - version information",
    "    --prefix PREFIX - prepends PREFIX to variables loaded from MAT file",
    "                      except variable names explicitly set using '='",
    "    --suffix SUFFIX - appends SUFFIX to variables loaded from MAT file",
    "                      except variable names explicitly set using '='",
    "",
    "  INPUT:",
    "    filename - MAT filename with .mat extension",
    "  OPTIONAL INPUT:",
    "    var1     - Name of variable to load",
    "    :",
    "    var#     - Name of variable to load",
    "",
    "  EXAMPLES:",
    "    >> load5 --prefix pre_ --suffix _suf dem dLat dLon TerrainHeight=th",
    "    >> whos",
    "      Name               Size                   Bytes  Class",
    "    ",
    "      pre_dLat_suf       1x1                        8  double array",
    "      pre_dLon_suf       1x1                        8  double array",
    "      th              1440x1441               2075040  uint8 array",
    "    ",
    "    Grand total is 2075042 elements using 2075056 bytes",
    "      ",   
    "    >>", 
    "",
    "",
    "    >> load5('--prefix','pre_','--suffix','_suf','dem.mat');",
    "    >> whos",
    "      Name                            Size                   Bytes  Class",
    "    ",
    "      pre_SouthmostLatitude_suf       1x1                        8  double array",
    "      pre_TerrainHeight_suf        1440x1441               2075040  uint8 array",
    "      pre_WestmostLongitude_suf       1x1                        8  double array",
    "      pre_dLat_suf                    1x1                        8  double array",
    "      pre_dLon_suf                    1x1                        8  double array",
    "    ",
    "    Grand total is 2075044 elements using 2075072 bytes",
    "    ",
    "    >>",
    NULL
};

static struct option long_options[] =
{
    {"help",   no_argument,       NULL, 'h'},
    {"prefix", required_argument, NULL, 'p'},
    {"suffix", required_argument, NULL, 's'},
    {"version", no_argument,      NULL, 'v'},
    {0, 0, 0, 0}
};

static void help( )
{
    int i;
    for (i = 0; helpstr[i] != NULL; i++)
        mexPrintf("%s\n",helpstr[i]);
}

static void usage( )
{
    int i;
    for (i = 0; helpstr[i] != NULL; i++)
        mexPrintf("%s\n",helpstr[i]);
    mexErrMsgTxt("");
}

size_t
mxClassID_SizeOf(int class_type)
{
    switch (class_type) {
        case mxDOUBLE_CLASS:
            return sizeof(double);
        case mxSINGLE_CLASS:
            return sizeof(float);
        case mxINT32_CLASS:
            return sizeof(int32_t);
        case mxUINT32_CLASS:
            return sizeof(uint32_t);
        case mxINT16_CLASS:
            return sizeof(int16_t);
        case mxUINT16_CLASS:
            return sizeof(uint16_t);
        case mxINT8_CLASS:
            return sizeof(int8_t);
        case mxUINT8_CLASS:
            return sizeof(uint8_t);
        case mxSTRUCT_CLASS:
            return sizeof(matvar_t **);
        case mxCELL_CLASS:
            return sizeof(matvar_t **);
        default:
            return 0;
    }
}

static int
slab_get_rank(char *open,char *close)
{
    int rank = 0;
    char *ptr = open+1;
    rank = 1;
    while ( ptr != close ) {
        if ( *ptr++ == ',' )
            rank++;
    }
    return rank;
}

static void
slab_get_select(char *open, char *close, int rank, int *start, int *stride, int *edge)
{
    char *ptr, *valptr;
    int nvals, dim, i;

    ptr = open;
    valptr = open+1;
    dim = 0;
    nvals = 0;
    do {
        ptr++;
        if ( *ptr == ',' ) {
            if (nvals == 2) {
                *ptr = '\0';
                 if ( !strcmp(valptr,"end") ) {
                     edge[dim] = -1;
                 } else {
                     i = atoi(valptr);
                     edge[dim] = i;
                 }
            } else if ( nvals == 1 ) {
                *ptr = '\0';
                 if ( !strcmp(valptr,"end") ) {
                     edge[dim] = -1;
                 } else {
                     i = atoi(valptr);
                     edge[dim] = i;
                 }
            } else if ( nvals == 0 ) {
                *ptr = '\0';
                 if ( !strcmp(valptr,"end") ) {
                     start[dim] = -1;
                     edge[dim]  = -1;
                 } else {
                     i = atoi(valptr);
                     start[dim] = i-1;
                     edge[dim]  = i;
                 }
            }
            dim++;
            valptr = ptr+1;
            nvals = 0;
        } else if ( *ptr == ':' ) {
            *ptr = '\0';
            if ( !strcmp(valptr,"end") ) {
                if ( nvals == 0 )
                    start[dim] = -1;
                else if ( nvals == 1 )
                    edge[dim] = -1;
                else if ( nvals == 2 )
                    edge[dim] = -1;
                else
                    Mex_Critical("Too many inputs to dim %d",dim+1);
            } else {
                i = atoi(valptr);
                if ( nvals == 0 )
                    start[dim] = i-1;
                else if ( nvals == 1 )
                    stride[dim] = i;
                else if ( nvals == 1 )
                    edge[dim] = i;
                else if ( nvals == 2 )
                    edge[dim] = i;
                else
                    Mex_Critical("Too many inputs to dim %d",dim+1);
            }
            nvals++;
            valptr = ptr+1;
        } else if ( *ptr == ')' ) {
            *ptr = '\0';
            if ( !strcmp(valptr,"end") ) {
                if ( nvals == 0 ) {
                    start[dim] = -1;
                    edge[dim]  = -1;
                } else if ( nvals == 1 )
                    edge[dim] = -1;
                else if ( nvals == 2 )
                    edge[dim] = -1;
                else
                    Mex_Critical("Too many inputs to dim %d",dim+1);
            } else {
                i = atoi(valptr);
                if ( nvals == 0 ) {
                    start[dim] = i-1;
                    edge[dim]  = i;
                } else if ( nvals == 1 )
                    edge[dim] = i;
                else if ( nvals == 2 )
                    edge[dim] = i;
                else
                    Mex_Critical("Too many inputs to dim %d",dim+1);
            }
            nvals++;
            valptr = ptr+1;
        }
    } while ( ptr != close );
}

static int
slab_select_valid(int rank,int *start,int *stride,int *edge,matvar_t *matvar)
{
    int valid = 1, i, nmemb = 1;;

    if ( matvar->rank != rank ) {
        valid = 0;
    } else {
        for ( i = 0; i < rank && valid; i++ ) {
            if ( stride[i] < 1 ) {
                Mex_Critical("stride must be positive");
                valid = 0;
                break;
            } else if ( edge[i] > matvar->dims[i] ) {
                Mex_Critical("edge out of bound on dimension %d",i+1);
                valid = 0;
                break;
            } else if ( start[i] >= matvar->dims[i] ||
                        (edge[i] > 0 && start[i] > edge[i]) ) {
                Mex_Critical("start out of bound on dimension %d",i+1);
                valid = 0;
                break;
            } else if ( edge[i] == -1 && start[i] == -1 ) {
                edge[i] = 1;
                start[i] = matvar->dims[i]-1;
            } else if ( edge[i] < 1 && stride[i] == 1) {
                edge[i] = matvar->dims[i];
            } else if ( edge[i] < 1 ) {
                edge[i] = floor((double)(matvar->dims[i]-start[i]-1) / (double)stride[i])+1;
            } else if ( edge[i] == (start[i]+1) ) {
                edge[i] = 1;
            } else if ( edge[i] > 0 ) {
                edge[i] = floor((double)(edge[i]-start[i]-1) / (double)stride[i])+1;
            }
            nmemb *= edge[i];
        }
    }
    if ( !valid )
        nmemb = 0;
    return nmemb;
}

static mat_t *
get_mat_file(char *matfile)
{
    mat_t *mat = NULL;
    mxArray *which[1], *args[1];
    int nlhs = 1, nrhs = 1,N;

    if ( !matfile ) return NULL;

    mat = NULL;
    if ( (mat = Mat_Open(matfile,MAT_ACC_RDONLY)) != NULL )
        return mat;

    args[0] = mxCreateString(matfile);

    nlhs = 1;
    nrhs = 1;
    mexCallMATLAB(nlhs,which,nrhs,args,"which");

    N = mxGetM(which[0])*mxGetN(which[0]);

    if ( N ) {
        char *name;
        name = (char *)malloc(N+1);
        mxGetString(which[0],name,N+1);
        mat = Mat_Open(name,MAT_ACC_RDONLY);
        free(name);
    }

    mxDestroyArray(which[0]);
    mxDestroyArray(args[0]);
        
    return mat;
}

static int
set_global(char *name)
{
    int err;
    char cmd[256];

    snprintf(cmd,256,"global %s",name);
    err = mexEvalString(cmd);
    return err;
}

/* load_vars - Loads the specified variables from the mat file
 * mat  - MAT file
 * vars - NULL terminated array of variable names
 * RETURNS
 * The number of variables loaded
 */
static int
load_vars(mat_t *mat, char **vars)
{
    char *as = NULL, *temp = NULL, *open = NULL, *close = NULL;
    int err, nvars = 0, i = 0, j;
    mxArray *array = NULL;
    matvar_t *matvar = NULL;

    while ( vars[i] != NULL ) {
        if ( (as = strchr(vars[i],'=')) ) {
            *as = '\0';
             as++;
        }
        /* Check If the user is selecting a subset of the dataset */
        if ( (open = strchr(vars[i],'(')) != NULL &&
                    (close = strchr(vars[i],')')) != NULL ) {
            int rank, *start, *stride, *edge,nmemb;

            *open = '\0';
            matvar = Mat_VarReadInfo(mat,vars[i]);
            if ( matvar == NULL ) {
                Mex_Critical("Couldn't find variable %s", vars[i]);
                i++;
                continue;
            } else if ( !isNumeric(matvar->class_type) ) {
                Mex_Critical("Only numeric data can use slabs");
                i++;
                continue;
            }
            /* Get the rank of the dataset */
            rank   = slab_get_rank(open,close);
            start  = malloc(rank*sizeof(int));
            stride = malloc(rank*sizeof(int));
            edge   = malloc(rank*sizeof(int));
            for ( j = 0; j < rank; j++ ) {
                start[j]  = 0;
                stride[j] = 1;
                edge[j]   = 1;
            }
            /* Get the start,stride,edge using matlab syntax */
            slab_get_select(open,close,rank,start,stride,edge);
            /* If the user is renaming it, set a prefix, or a suffix apply it */
            if ( as ) {
                free(matvar->name);
                matvar->name = strdup_printf("%s",as);
            } else if ( prefix && suffix ) {
                temp = strdup_printf("%s%s%s",prefix,matvar->name,suffix);
                free(matvar->name);
                matvar->name = temp;
            } else if ( prefix ) {
                temp = strdup_printf("%s%s",prefix,matvar->name);
                free(matvar->name);
                matvar->name = temp;
            } else if ( suffix ) {
                temp = strdup_printf("%s%s",matvar->name,suffix);
                free(matvar->name);
                matvar->name = temp;
            }
            /* Check if the users selection is valid and if so read the data */
            if ((nmemb = slab_select_valid(rank,start,stride,edge,matvar))) {
                matvar->nbytes = nmemb*mxClassID_SizeOf(matvar->class_type);
                matvar->data = malloc(matvar->nbytes);
                if ( matvar->data == NULL ) {
                    Mex_Critical("Couldn't allocate memory for the data");
                } else {
                    Mat_VarReadData(mat,matvar,matvar->data,start,stride,edge);
                    memcpy(matvar->dims,edge,rank*sizeof(int));
                    array = MatVarToMxArray(matvar);
                    if ( (array != NULL) && !matvar->isGlobal ) {
                        err = mexPutVariable("caller",matvar->name,array);
                        mxDestroyArray(array);
                        nvars++;
                    } else if ( (array != NULL) && matvar->isGlobal ) {
                        err = mexPutVariable("global",matvar->name,array);
                        err = set_global(matvar->name);
                        mxDestroyArray(array);
                        nvars++;
                    }
                }
            }
            Mat_VarFree(matvar);
            matvar = NULL;
            free(start);
            free(stride);
            free(edge);
        } else {
            matvar = Mat_VarRead(mat,vars[i]);
            if ( !matvar ) {
                Mex_Message("Couldn't find variable %s", vars[i]);
                i++;
                continue;
            }
            if ( as ) {
                free(matvar->name);
                matvar->name = strdup_printf("%s",as);
            } else if ( prefix && suffix ) {
                temp = strdup_printf("%s%s%s",prefix,matvar->name,suffix);
                free(matvar->name);
                matvar->name = temp;
            } else if ( prefix ) {
                temp = strdup_printf("%s%s",prefix,matvar->name);
                free(matvar->name);
                matvar->name = temp;
            } else if ( suffix ) {
                temp = strdup_printf("%s%s",matvar->name,suffix);
                free(matvar->name);
                matvar->name = temp;
            }
            array = MatVarToMxArray(matvar);
            if ( (array != NULL) && !matvar->isGlobal ) {
                err = mexPutVariable("caller",matvar->name,array);
                mxDestroyArray(array);
                nvars++;
            } else if ( (array != NULL) && matvar->isGlobal ) {
                err = mexPutVariable("global",matvar->name,array);
                err = set_global(matvar->name);
                mxDestroyArray(array);
                nvars++;
            }
            Mat_VarFree(matvar);
            matvar = NULL;
        }
        i++;
    }
    return nvars;
}

/* load_all_mat - Loads all the variables from the mat file
 * mat  - MAT file
 * RETURNS
 * The number of variables loaded
 */
static int
load_all_mat(mat_t *mat)
{
    char *temp, varname[512];
    int err, nvars = 0;
    mxArray *array = NULL;
    matvar_t *matvar = NULL;

    while ( (matvar = Mat_VarReadNext(mat)) != NULL ) {
        if ( prefix != NULL && suffix != NULL ) {
            temp = strdup_printf("%s%s%s",prefix,matvar->name,suffix);
            free(matvar->name);
            matvar->name = temp;
        } else if ( prefix ) {
            temp = strdup_printf("%s%s",prefix,matvar->name);
            free(matvar->name);
            matvar->name = temp;
        } else if ( suffix ) {
            temp = strdup_printf("%s%s",matvar->name,suffix);
            free(matvar->name);
            matvar->name = temp;
        }
        array = MatVarToMxArray(matvar);
        if ( (array != NULL) && !matvar->isGlobal ) {
            err = mexPutVariable("caller",matvar->name,array);
            mxDestroyArray(array);
            nvars++;
        } else if ( (array != NULL) && matvar->isGlobal ) {
            err = mexPutVariable("global",matvar->name,array);
            err = set_global(matvar->name);
            mxDestroyArray(array);
            nvars++;
        }
        Mat_VarFree(matvar);
        matvar = NULL;
    }

    return nvars;
}

void mexFunction ( int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[] )
{
    char *mex_name = "load5", *matfname = NULL, path, *ext;
    int N, err, nvars;
    mat_t *mat = NULL;
    int c, option_index, format;
    int nmalloc,ncalloc,nfree;

    prefix = NULL;
    suffix = NULL;
    mexoptind = 0;

    if ( nrhs < 1 )
        usage();
    if ( nlhs > 0 )
        usage();

    Mex_LogInit(mex_name);

    mexoptind = 0;
    while (-1 != (c=mexgetopt_long(nrhs,prhs,"hp:s:v",long_options,&option_index))) {
        switch(c) {
            case 'h':
                help();
        return;
            case 'v':
                mexPrintf("load5 v%d.%d.%d (compiled %s, %s for %s)\n",
                          LOAD5_MAJOR_VERSION,LOAD5_MINOR_VERSION,
                          LOAD5_RELEASE_LEVEL,__DATE__, __TIME__,
                          LOAD5_PLATFORM );
                return;
            case 'p':                  /*   Prefix  */
                if ( mexoptarg != NULL ) {
                    prefix = strdup(mexoptarg);
                } else if ( mxArrayoptarg != NULL ) {
                    N = mxGetM(mxArrayoptarg)*mxGetN(mxArrayoptarg);
                    prefix = malloc(N+1);
                    if ( prefix != NULL )
                        mxGetString(mxArrayoptarg,prefix,N+1);
                    else
                        Mex_Error("Couldn't allocate memory for --prefix argument");
                }
                break;
            case 's':                  /*   Suffix  */
                if ( mexoptarg != NULL ) {
                    suffix = strdup(mexoptarg);
                } else if ( mxArrayoptarg != NULL ) {
                    N = mxGetM(mxArrayoptarg)*mxGetN(mxArrayoptarg);
                    suffix = malloc(N+1);
                    if ( suffix != NULL )
                        mxGetString(mxArrayoptarg,suffix,N+1);
                    else
                        Mex_Error("Couldn't allocate memory for --suffix argument");
                }
		break;
            case ':':                  /*   BADARG   */
            default:
                Mex_Error("Aborting from argument errors");
        }
    }

    if ( mexoptind >= nrhs )
        Mex_Error("No files found");

    N = get_vector_size(prhs[mexoptind])+1;
    matfname = (char *)malloc(N+1);
    if ( matfname == NULL )
        Mex_Error("Couldn't get mat filename");
    err = mxGetString(prhs[mexoptind++],matfname,N);

    if ( matfname == '\0' )
        Mex_Error("'' is not a valid filename");

    if ( NULL == (ext = strrchr(matfname,'.')) ) {
        char *temp;
        temp = strdup_printf("%s.mat",matfname);
        free(matfname);
        matfname = temp;
        mat = get_mat_file(matfname);
        format = SCATS_FT_MAT5;
    } else if ( !strcmp(ext,".mat") ) {
        mat = get_mat_file(matfname);
        format = SCATS_FT_MAT5;
    } else {
        Mex_Error("Format doesn't appear to be a mat file");
    }

    if ( mat == NULL )
        Mex_Error("Couldn't open mat file %s",matfname);

    free(matfname);

    if ( nrhs-mexoptind < 1 ) {
        if ( format == SCATS_FT_MAT5 )
            nvars = load_all_mat(mat);
    } else {
        char **varnames;
        int nvars, i;

        nvars = nrhs-mexoptind;
        varnames = (char **)malloc((nvars+1)*sizeof(char *));
        if ( !varnames ) {
            Mex_Critical("Couldn't get list of the variable names");
            Mat_Close(mat);
            return;
        }
        for ( i = 0; i < nvars; i++ ) {
            N = get_vector_size(prhs[mexoptind])+1;
            varnames[i] = (char *)malloc(N+1);
            if ( !varnames[i] ) {
                Mex_Critical("Couldn't get variable name for index %d",i);
                mexoptind++;
                nvars--;
                i--;
                continue;
            }
            err = mxGetString(prhs[mexoptind++],varnames[i],N);
        }
        varnames[nvars] = NULL;
        err = load_vars(mat,varnames);
        for ( i = 0; i < nvars; i++ )
            if ( varnames[i] )
                free(varnames[i]);
        free(varnames);
    }

    if ( format == SCATS_FT_MAT5 )
        Mat_Close(mat);

    if ( prefix != NULL ) {
        free(prefix);
        prefix = NULL;
    }
    if ( suffix != NULL ) {
        free(suffix);
        suffix = NULL;
    }

#if 0
    MexMemProfile(&nmalloc,&ncalloc,&nfree);
    Mex_Message("End MEX\n----------------------------------------------\n"
                "mexoptind = %d\nnmalloc = %d\nncalloc = %d\nnfree = %d",
                mexoptind,nmalloc,ncalloc,nfree);
#endif

    return;
}
