/*
 * $Revision: 1.1 $ $State: Exp $
 * $Date: 2005/06/24 13:45:32 $
 */
#include <string.h>
#include <mex.h>

void *
__wrap_strdup(char *s)
{
    char *s2 = NULL;
    int n;

    if ( !s )    return NULL;
    n = strlen(s);
    s2 = mxCalloc(1,n+1);
    memcpy(s2,s,n);
    return s2;
}
